from app.chatbot.validator import HallucinationValidator


def test_validator_passes_when_price_in_context():
    v = HallucinationValidator()
    sql_rows = [{"title": "Royal Blue Saree", "base_price": 1899.00}]
    res = v.validate(
        'Our "Royal Blue Saree" is available for ₹1899. Shall I add it to your cart?',
        sql_rows=sql_rows,
        vector_hits=[],
    )
    assert res.valid, res.offending


def test_validator_flags_unsupported_price():
    v = HallucinationValidator()
    sql_rows = [{"title": "Royal Blue Saree", "base_price": 1899.00}]
    res = v.validate(
        "Our Royal Blue Saree is on sale for ₹999 today.",
        sql_rows=sql_rows,
        vector_hits=[],
    )
    assert not res.valid
    assert any("unsupported_price" in o for o in (res.offending or []))


def test_validator_flags_unsupported_order_number():
    v = HallucinationValidator()
    res = v.validate(
        "Your order SS-XX2605161132402 has shipped.",
        sql_rows=[{"order_number": "SS-YY2605160000000"}],
        vector_hits=[],
    )
    assert not res.valid
    assert any("unsupported_order" in o for o in (res.offending or []))


def test_validator_allows_response_without_prices():
    v = HallucinationValidator()
    res = v.validate(
        "We accept returns within 7 days of delivery for unworn items.",
        sql_rows=[],
        vector_hits=[],
    )
    assert res.valid
