"""Read-only repositories against the live Prisma-managed schema.

Tables this module reads (NEVER writes to):
    public.products
    public.product_variants
    public.categories
    public.orders
    public.shipments
    public.shipment_tracking

Filter values from the LLM extractor are mapped to the real column types here
(e.g. customer-friendly "female" -> Gender enum "WOMEN"). All queries are
parameterised; nothing the LLM produces ever reaches SQL as raw text.
"""
from __future__ import annotations

import re
import time
from decimal import Decimal
from typing import Any

from sqlalchemy import text

from app.core.exceptions import UnsafeSQLError
from app.core.metrics import SQL_LATENCY
from app.db.session import session_scope

# ---------------------------------------------------------------
# SQL safety (defensive — currently no AI-generated SQL is used)
# ---------------------------------------------------------------

_FORBIDDEN_TOKENS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE|GRANT|REVOKE|"
    r"COPY|VACUUM|ATTACH|MERGE|CALL|DO)\b",
    re.IGNORECASE,
)
_MULTI_STMT = re.compile(r";\s*\S")


def assert_safe_select(sql: str) -> None:
    stripped = sql.strip().rstrip(";")
    if not stripped.lower().startswith("select"):
        raise UnsafeSQLError("only SELECT statements are allowed")
    if _MULTI_STMT.search(stripped):
        raise UnsafeSQLError("multiple statements are not allowed")
    if _FORBIDDEN_TOKENS.search(stripped):
        raise UnsafeSQLError("forbidden SQL keyword detected")


# ---------------------------------------------------------------
# Filter mapping
# ---------------------------------------------------------------

_GENDER_MAP = {
    "female": "WOMEN", "women": "WOMEN", "woman": "WOMEN", "ladies": "WOMEN",
    "male": "MEN",     "men": "MEN",     "man": "MEN",     "gents": "MEN",
    "kids": "KIDS",    "kid": "KIDS",    "children": "KIDS", "child": "KIDS",
}


def _map_gender(value: str | None) -> str | None:
    if not value:
        return None
    return _GENDER_MAP.get(value.lower())


# ---------------------------------------------------------------
# Products
# ---------------------------------------------------------------


class ProductRepository:
    """Read-only product search against public.products + product_variants.

    WHERE / HAVING clauses are appended dynamically based on which filters
    are actually present. This avoids SQLAlchemy's bind-vs-cast (`:x::text`)
    ambiguity and keeps the planner from evaluating dead `IS NULL` branches.
    """

    @staticmethod
    async def search(
        *,
        category: str | None = None,
        color: str | None = None,
        size: str | None = None,
        style: str | None = None,        # ignored — not in schema; used for vector only
        occasion: str | None = None,     # ignored — not in schema; used for vector only
        gender: str | None = None,
        max_price: Decimal | float | None = None,
        min_price: Decimal | float | None = None,
        limit: int = 10,
    ) -> tuple[list[dict[str, Any]], str]:
        where: list[str] = ["p.status = 'ACTIVE'"]
        having: list[str] = []
        params: dict[str, Any] = {"limit": limit}

        mapped_gender = _map_gender(gender)
        if mapped_gender is not None:
            where.append("p.gender::text = :gender")
            params["gender"] = mapped_gender
        if category is not None:
            # Fuzzy match — the catalog uses titles like "Crop Tops" or "Tops & Tees".
            where.append("LOWER(c.name) LIKE LOWER(:category_like)")
            params["category_like"] = f"%{category}%"
        if min_price is not None:
            where.append("p.base_price >= :min_price")
            params["min_price"] = float(min_price)
        if max_price is not None:
            where.append("p.base_price <= :max_price")
            params["max_price"] = float(max_price)

        if color is not None:
            having.append(
                "EXISTS (SELECT 1 FROM product_variants v "
                "WHERE v.product_id = p.id AND v.is_active = TRUE "
                "AND LOWER(v.color) = LOWER(:color) AND v.stock_quantity > 0)"
            )
            params["color"] = color
        if size is not None:
            having.append(
                "EXISTS (SELECT 1 FROM product_variants v "
                "WHERE v.product_id = p.id AND v.is_active = TRUE "
                "AND LOWER(v.size) = LOWER(:size) AND v.stock_quantity > 0)"
            )
            params["size"] = size

        sql = (
            "SELECT "
            "  p.id, p.title, p.description, p.base_price, p.suggested_mrp, "
            "  p.gender::text AS gender, p.fabric, p.images, p.search_keywords, "
            "  c.name AS category_name, "
            "  COALESCE(SUM(pv.stock_quantity), 0) AS total_stock, "
            "  ARRAY_AGG(DISTINCT pv.color) FILTER (WHERE pv.color IS NOT NULL) AS available_colors, "
            "  ARRAY_AGG(DISTINCT pv.size)  FILTER (WHERE pv.size  IS NOT NULL) AS available_sizes "
            "FROM products p "
            "LEFT JOIN categories c ON c.id = p.category_id "
            "LEFT JOIN product_variants pv ON pv.product_id = p.id AND pv.is_active = TRUE "
            f"WHERE {' AND '.join(where)} "
            "GROUP BY p.id, c.name "
            + (f"HAVING {' AND '.join(having)} " if having else "")
            + "ORDER BY p.base_price ASC LIMIT :limit"
        )

        start = time.perf_counter()
        async with session_scope() as session:
            res = await session.execute(text(sql), params)
            rows = [dict(r._mapping) for r in res]
        SQL_LATENCY.labels(op="product_search").observe(time.perf_counter() - start)
        return rows, sql

    @staticmethod
    async def get_by_ids(ids: list[str]) -> list[dict[str, Any]]:
        if not ids:
            return []
        sql = text(
            """
            SELECT
                p.id, p.title, p.description, p.base_price, p.suggested_mrp,
                p.gender::text AS gender, p.images, p.fabric,
                c.name AS category_name,
                COALESCE(SUM(pv.stock_quantity), 0) AS total_stock,
                ARRAY_AGG(DISTINCT pv.color) FILTER (WHERE pv.color IS NOT NULL) AS available_colors,
                ARRAY_AGG(DISTINCT pv.size)  FILTER (WHERE pv.size  IS NOT NULL) AS available_sizes
            FROM products p
            LEFT JOIN categories c ON c.id = p.category_id
            LEFT JOIN product_variants pv ON pv.product_id = p.id AND pv.is_active = TRUE
            WHERE p.id = ANY(:ids) AND p.status = 'ACTIVE'
            GROUP BY p.id, c.name
            """
        )
        start = time.perf_counter()
        async with session_scope() as session:
            res = await session.execute(sql, {"ids": ids})
            # Preserve vector-relevance order: re-sort by the input order.
            rank = {pid: i for i, pid in enumerate(ids)}
            rows = sorted(
                (dict(r._mapping) for r in res),
                key=lambda r: rank.get(str(r["id"]), 10_000),
            )
        SQL_LATENCY.labels(op="product_lookup").observe(time.perf_counter() - start)
        return rows

    @staticmethod
    async def iter_active_for_embedding() -> list[dict[str, Any]]:
        """Pull all ACTIVE products for the reindex flow."""
        sql = text(
            """
            SELECT
                p.id, p.title, p.description, p.gender::text AS gender,
                p.fabric, p.search_keywords,
                c.name AS category_name,
                ARRAY_AGG(DISTINCT pv.color) FILTER (WHERE pv.color IS NOT NULL) AS available_colors,
                ARRAY_AGG(DISTINCT pv.size)  FILTER (WHERE pv.size  IS NOT NULL) AS available_sizes
            FROM products p
            LEFT JOIN categories c ON c.id = p.category_id
            LEFT JOIN product_variants pv ON pv.product_id = p.id AND pv.is_active = TRUE
            WHERE p.status = 'ACTIVE'
            GROUP BY p.id, c.name
            """
        )
        async with session_scope() as session:
            res = await session.execute(sql)
            return [dict(r._mapping) for r in res]


# ---------------------------------------------------------------
# Orders
# ---------------------------------------------------------------


class OrderRepository:
    @staticmethod
    async def get_by_number(
        order_number: str, customer_ref: str | None = None
    ) -> dict[str, Any] | None:
        base = (
            "SELECT "
            "  o.order_number, o.customer_name, o.customer_phone, o.customer_email, "
            "  o.order_status::text   AS order_status, "
            "  o.payment_status::text AS payment_status, "
            "  o.total_amount, o.created_at, o.updated_at, "
            "  s.awb_number AS tracking_number, s.courier_name, "
            "  s.status::text AS shipment_status, "
            "  s.estimated_delivery, s.tracking_url "
            "FROM orders o "
            "LEFT JOIN shipments s ON s.order_id = o.id "
            "WHERE o.order_number = :order_number"
        )
        params: dict[str, Any] = {"order_number": order_number}
        if customer_ref:
            base += " AND (o.customer_phone = :ref OR o.customer_email = :ref)"
            params["ref"] = customer_ref

        start = time.perf_counter()
        async with session_scope() as session:
            res = await session.execute(text(base), params)
            row = res.first()
        SQL_LATENCY.labels(op="order_lookup").observe(time.perf_counter() - start)
        return dict(row._mapping) if row else None

    @staticmethod
    async def latest_for_customer(customer_ref: str, limit: int = 5) -> list[dict[str, Any]]:
        sql = text(
            """
            SELECT
                o.order_number,
                o.order_status::text   AS order_status,
                o.payment_status::text AS payment_status,
                o.total_amount,
                o.created_at
            FROM orders o
            WHERE o.customer_phone = :ref OR o.customer_email = :ref
            ORDER BY o.created_at DESC
            LIMIT :limit
            """
        )
        start = time.perf_counter()
        async with session_scope() as session:
            res = await session.execute(sql, {"ref": customer_ref, "limit": limit})
            rows = [dict(r._mapping) for r in res]
        SQL_LATENCY.labels(op="order_history").observe(time.perf_counter() - start)
        return rows
