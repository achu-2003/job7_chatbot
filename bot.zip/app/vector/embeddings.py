"""Local embedding client backed by fastembed (ONNX, CPU)."""
from __future__ import annotations

import asyncio
import time
from typing import Sequence

from fastembed import TextEmbedding

from app.config import get_settings
from app.core.logging import get_logger
from app.core.metrics import OPENAI_LATENCY

log = get_logger("embeddings")

_model: TextEmbedding | None = None
_model_lock = asyncio.Lock()


async def _get_model() -> TextEmbedding:
    """Lazy-load the embedding model once per process."""
    global _model
    if _model is not None:
        return _model
    async with _model_lock:
        if _model is None:
            s = get_settings()
            loop = asyncio.get_running_loop()
            _model = await loop.run_in_executor(
                None, lambda: TextEmbedding(model_name=s.local_embed_model)
            )
            log.info("local_embed_model_loaded", model=s.local_embed_model)
    return _model


class EmbeddingClient:
    """Async-friendly wrapper around fastembed's synchronous embed()."""

    def __init__(self, _client: object | None = None) -> None:
        # _client kept for signature parity with the previous OpenAI version.
        self._settings = get_settings()

    async def embed(self, texts: Sequence[str]) -> list[list[float]]:
        if not texts:
            return []
        model = await _get_model()
        start = time.perf_counter()
        loop = asyncio.get_running_loop()
        # fastembed.embed returns a generator of numpy arrays; force a list.
        vectors = await loop.run_in_executor(
            None, lambda: [v.tolist() for v in model.embed(list(texts))]
        )
        OPENAI_LATENCY.labels(
            model=self._settings.local_embed_model, purpose="embed"
        ).observe(time.perf_counter() - start)
        return vectors
