"""ChromaDB client wrapper.

Only semantic content is stored: product descriptions, FAQs, policies.
Transactional fields (price, stock, payment_status, order status) are NEVER
written to the vector DB — they live in PostgreSQL.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any

import chromadb
from chromadb.api import ClientAPI
from chromadb.config import Settings as ChromaSettings

from app.config import get_settings
from app.core.logging import get_logger
from app.core.metrics import VECTOR_LATENCY
from app.vector.embeddings import EmbeddingClient

log = get_logger("vector_store")


class VectorStore:
    """Async-friendly facade over the synchronous chromadb client."""

    def __init__(self) -> None:
        self._client: ClientAPI | None = None
        self._collections: dict[str, Any] = {}
        self._embed = EmbeddingClient()
        self._lock = asyncio.Lock()

    async def connect(self) -> None:
        s = get_settings()
        loop = asyncio.get_running_loop()

        def _build() -> ClientAPI:
            if s.vector_mode == "embedded":
                import os
                os.makedirs(s.chroma_persist_dir, exist_ok=True)
                return chromadb.PersistentClient(
                    path=s.chroma_persist_dir,
                    settings=ChromaSettings(anonymized_telemetry=False),
                )
            return chromadb.HttpClient(
                host=s.chroma_host,
                port=s.chroma_port,
                settings=ChromaSettings(anonymized_telemetry=False),
            )

        self._client = await loop.run_in_executor(None, _build)
        for name in (
            s.chroma_collection_products,
            s.chroma_collection_faq,
            s.chroma_collection_policies,
        ):
            self._collections[name] = await loop.run_in_executor(
                None,
                lambda n=name: self._client.get_or_create_collection(
                    name=n, metadata={"hnsw:space": "cosine"}
                ),
            )
        log.info("vector_store_ready", collections=list(self._collections.keys()))

    async def close(self) -> None:
        self._collections.clear()
        self._client = None

    # ----- write side (called from worker) -----

    async def upsert(
        self,
        collection: str,
        *,
        ids: list[str],
        documents: list[str],
        metadatas: list[dict[str, Any]] | None = None,
    ) -> None:
        if not ids:
            return
        embeddings = await self._embed.embed(documents)
        col = self._collections[collection]
        await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: col.upsert(
                ids=ids,
                documents=documents,
                embeddings=embeddings,
                metadatas=metadatas,
            ),
        )
        log.info("vector_upsert", collection=collection, n=len(ids))

    async def delete(self, collection: str, ids: list[str]) -> None:
        if not ids:
            return
        col = self._collections[collection]
        await asyncio.get_running_loop().run_in_executor(
            None, lambda: col.delete(ids=ids)
        )
        log.info("vector_delete", collection=collection, n=len(ids))

    # ----- read side (called from chat path) -----

    async def query(
        self,
        collection: str,
        text: str,
        *,
        top_k: int | None = None,
        where: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        s = get_settings()
        top_k = top_k or s.vector_top_k
        embeddings = await self._embed.embed([text])
        if not embeddings:
            return []

        col = self._collections[collection]
        start = time.perf_counter()
        result = await asyncio.get_running_loop().run_in_executor(
            None,
            lambda: col.query(
                query_embeddings=embeddings,
                n_results=top_k,
                where=where,
            ),
        )
        VECTOR_LATENCY.labels(collection=collection).observe(time.perf_counter() - start)

        ids = (result.get("ids") or [[]])[0]
        docs = (result.get("documents") or [[]])[0]
        metas = (result.get("metadatas") or [[]])[0]
        dists = (result.get("distances") or [[]])[0]
        return [
            {"id": i, "document": d, "metadata": m or {}, "distance": dist}
            for i, d, m, dist in zip(ids, docs, metas, dists)
        ]
