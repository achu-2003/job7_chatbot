"""Prometheus metrics. Scraped at /metrics."""
from __future__ import annotations

from prometheus_client import Counter, Histogram

HTTP_REQUESTS = Counter(
    "chatbot_http_requests_total",
    "HTTP requests grouped by method/path/status",
    ["method", "path", "status"],
)
HTTP_LATENCY = Histogram(
    "chatbot_http_request_latency_seconds",
    "End-to-end HTTP request latency",
    ["method", "path"],
    buckets=(0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10),
)

SQL_LATENCY = Histogram(
    "chatbot_sql_latency_seconds",
    "PostgreSQL query latency",
    ["op"],
    buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2),
)

VECTOR_LATENCY = Histogram(
    "chatbot_vector_latency_seconds",
    "Vector retrieval latency",
    ["collection"],
    buckets=(0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2),
)

OPENAI_TOKENS = Counter(
    "chatbot_openai_tokens_total",
    "OpenAI tokens consumed",
    ["model", "kind"],  # kind = prompt | completion
)

OPENAI_LATENCY = Histogram(
    "chatbot_openai_latency_seconds",
    "OpenAI call latency",
    ["model", "purpose"],
    buckets=(0.1, 0.25, 0.5, 1, 2, 5, 10, 20),
)

INTENT_COUNTER = Counter(
    "chatbot_intent_total",
    "Detected intents",
    ["intent"],
)

ROUTING_COUNTER = Counter(
    "chatbot_routing_total",
    "Retrieval routing decisions",
    ["sql_used", "vector_used"],
)

HALLUCINATION_COUNTER = Counter(
    "chatbot_validation_total",
    "Hallucination validation outcomes",
    ["result"],  # VALID | REGENERATED | ESCALATED
)

ERROR_COUNTER = Counter(
    "chatbot_errors_total",
    "Unhandled errors by layer",
    ["layer"],
)

EMBED_QUEUE_DEPTH = Histogram(
    "chatbot_embed_queue_depth",
    "Embedding queue depth observed by worker",
    buckets=(0, 1, 5, 10, 50, 100, 500, 1000),
)
