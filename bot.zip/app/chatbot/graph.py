"""LangGraph orchestration with intent-based LLM gating.

Goals:
- Use Groq sparingly. Facet follow-ups, list views, simple lookups → template.
- Only "give me details about <product>" / open-ended queries → Groq call.
- TOON-encoded LLM context (~35% fewer tokens than indented JSON).
- Same memory, vector store, and Postgres backends as before.
"""
from __future__ import annotations

import time
import uuid
from typing import Any, Literal, TypedDict

from langgraph.graph import END, START, StateGraph

from app.chatbot.memory import ConversationMemory
from app.chatbot.toon import encode as toon_encode
from app.chatbot.validator import HallucinationValidator
from app.config import get_settings
from app.core.logging import get_logger
from app.db.repositories import OrderRepository, ProductRepository
from app.llm.client import LLMClient
from app.vector.store import VectorStore

log = get_logger("graph")

# Lightweight system prompt — terser than RESPONSE_SYSTEM so the small
# context envelope stays small.
GRAPH_SYSTEM_PROMPT = (
    "You are a customer-support assistant for an Indian ethnic-wear store.\n"
    "Answer ONLY using facts present in the CONTEXT block below. If a fact is\n"
    "not in the context, say you don't have that information — never invent.\n"
    "Never invent product names, prices, SKUs, stock numbers, sizes, or colors.\n"
    "\n"
    "If the customer asks for a specific category (sarees, kurtis, footwear,\n"
    "lehengas, dupattas, bags, gowns, etc.), include ONLY products whose\n"
    "category matches the request. If none of the products in CONTEXT match,\n"
    "say 'I couldn't find any <category> in our catalogue right now' — do\n"
    "not list unrelated products.\n"
    "\n"
    "All prices are in Indian rupees — always write them as '₹<amount>'.\n"
    "Never write '$' or any other currency symbol.\n"
    "\n"
    "Keep answers short and direct. No greetings, no upselling."
)


# ---------------------------------------------------------------------------
# state
# ---------------------------------------------------------------------------

class ChatState(TypedDict, total=False):
    # input
    conversation_id: str
    customer_query: str
    customer_external_id: str | None
    channel: str
    request_id: str
    started: float
    # loaded from memory
    history: list[dict[str, str]]
    cached_product: dict[str, str] | None
    # retrieval
    intent: str
    vector_hits: list[dict[str, Any]]
    sql_rows: list[dict[str, Any]]
    order_rows: list[dict[str, Any]]
    # routing
    route: Literal["template", "llm"]
    # output
    response: str
    used_llm: bool
    latency_ms: int


# ---------------------------------------------------------------------------
# heuristics
# ---------------------------------------------------------------------------

import re

_GREETING_RX = re.compile(
    r"^\s*(hi|hello|hey|namaste|good\s*(morning|afternoon|evening))[\s!\.?]*$",
    re.IGNORECASE,
)
_ORDER_RX = re.compile(
    r"\b(orders?|tracking|shipment|delivered?|awb|status\s+of|my\s+order(s)?)\b",
    re.IGNORECASE,
)
_ORDER_NUMBER_RX = re.compile(r"\b(SS-[A-Z]{2}\d{8,}|ORD[-_]?\d{3,})\b", re.IGNORECASE)
_RETURN_RX = re.compile(r"\b(return|refund|exchange)\b", re.IGNORECASE)
_FAQ_RX = re.compile(r"\b(policy|policies|how (do|to)|shipping|delivery time)\b", re.IGNORECASE)

_FACET_KEYWORDS = (
    "size", "color", "colour", "stock", "available", "left",
    "price", "cost", "rate", "rupee", "fabric", "material", "made of",
)
_PRODUCT_NOUNS = (
    "saree", "sari", "halfsaree",
    "kurti", "kurta", "kurtha", "kurthi", "kurthis", "kurtis",
    "lehenga", "anarkali", "gown", "dress", "top", "shirt", "dupatta",
    "skirt", "bag", "clutch", "jewellery", "jewelry", "jewel",
    # Footwear: catch real word + common plural/typo variants the catalog
    # has seen (footwears / footwares / shoes / sandals / slippers).
    "footwear", "footwears", "footware", "footwares",
    "shoe", "sandal", "slipper",
    "suit", "blouse", "frock", "palazzo", "patiyala", "sharara",
    "chudidaar", "churidar", "shawl", "co-ord", "coord",
)
_DETAILS_TRIGGER = re.compile(
    r"\b(detail|details|tell me|about|describe|info|information|explain|recommend)\b",
    re.IGNORECASE,
)


def _is_facet_followup(q: str) -> bool:
    q = q.lower()
    return any(kw in q for kw in _FACET_KEYWORDS)


def _mentions_product_noun(q: str) -> bool:
    q = q.lower()
    return any(n in q for n in _PRODUCT_NOUNS)


def _wants_details(q: str) -> bool:
    return bool(_DETAILS_TRIGGER.search(q))


# ---------------------------------------------------------------------------
# nodes
# ---------------------------------------------------------------------------

class ChatGraphRunner:
    """Holds backend handles (memory, vector, llm) + compiled graph."""

    def __init__(
        self,
        *,
        vector: VectorStore,
        memory: ConversationMemory,
        llm: LLMClient | None = None,
    ) -> None:
        self.vector = vector
        self.memory = memory
        self.llm = llm or LLMClient()
        self.validator = HallucinationValidator()
        self._graph = self._build_graph()

    # -- node implementations -------------------------------------------------

    async def _load_memory(self, state: ChatState) -> ChatState:
        conv = state["conversation_id"]
        history = await self.memory.history(conv)
        cached = await self.memory.get_last_product(conv)
        return {"history": history, "cached_product": cached}

    async def _classify_intent(self, state: ChatState) -> ChatState:
        q = state["customer_query"]
        if _GREETING_RX.match(q):
            return {"intent": "greeting"}
        # Order number in the message → always treat as order tracking,
        # even if no other order-related keyword is present.
        if _ORDER_NUMBER_RX.search(q) or _ORDER_RX.search(q):
            return {"intent": "order_tracking"}
        if _RETURN_RX.search(q):
            return {"intent": "return_request"}
        if _FAQ_RX.search(q):
            return {"intent": "faq"}
        return {"intent": "product_search"}

    async def _retrieve(self, state: ChatState) -> ChatState:
        """Always run vector retrieval on the products collection. FAQs and
        return-policy intents additionally query their own collections.

        Greetings still get vector hits — they just won't be surfaced because
        the greeting template doesn't read them. Order-tracking gets product
        hits too in case the customer mixed a product question into their
        order-status message.
        """
        intent = state.get("intent", "product_search")
        s = get_settings()
        q = state["customer_query"]

        # Vector-first: every query searches the products catalog.
        hits = await self.vector.query(s.chroma_collection_products, q)
        log.info(
            "vector_search",
            request_id=state.get("request_id"),
            collection=s.chroma_collection_products,
            query=q,
            hits=_format_hits(hits),
        )

        # FAQ / return-policy intents also retrieve from their own collections.
        if intent == "faq":
            faq_hits = await self.vector.query(s.chroma_collection_faq, q)
            log.info(
                "vector_search",
                request_id=state.get("request_id"),
                collection=s.chroma_collection_faq,
                query=q,
                hits=_format_hits(faq_hits),
            )
            hits = (faq_hits or []) + (hits or [])
        elif intent == "return_request":
            pol_hits = await self.vector.query(s.chroma_collection_policies, q)
            log.info(
                "vector_search",
                request_id=state.get("request_id"),
                collection=s.chroma_collection_policies,
                query=q,
                hits=_format_hits(pol_hits),
            )
            hits = (pol_hits or []) + (hits or [])

        # Hydrate SQL rows from the product hits so downstream nodes (template
        # or LLM) have authoritative price/stock data.
        sql_rows: list[dict[str, Any]] = []
        product_ids = [
            h["id"] for h in hits
            if h.get("id") and (h.get("metadata") or {}).get("product_id")
        ]
        if product_ids:
            sql_rows = await ProductRepository.get_by_ids(product_ids)

        # Orders: look up by number if the message contains one, otherwise
        # by the customer's phone/email if we have it. WhatsApp passes the
        # sender's number with the country code prefix (e.g. 91…); the
        # orders table stores phones without it, so we try both forms.
        order_rows: list[dict[str, Any]] = []
        if intent == "order_tracking":
            q = state["customer_query"]
            m = _ORDER_NUMBER_RX.search(q)
            external_id = state.get("customer_external_id")
            if m:
                refs = _phone_variants(external_id) if external_id else [None]
                for ref in refs:
                    row = await OrderRepository.get_by_number(
                        m.group(0).upper(), customer_ref=ref,
                    )
                    if row:
                        order_rows = [row]
                        break
            elif external_id:
                refs = _phone_variants(external_id)
                for ref in refs:
                    order_rows = await OrderRepository.latest_for_customer(ref)
                    if order_rows:
                        break

        # Hydrate the cached product when the new turn looks like a follow-up
        # (no product noun, weak retrieval or facet keyword present).
        cached = state.get("cached_product")
        q = state["customer_query"]
        if (
            cached
            and cached.get("product_id")
            and not _mentions_product_noun(q)
            and (_is_facet_followup(q) or not hits or hits[0].get("distance", 1.0) > 0.6)
        ):
            already_present = any(
                str(r.get("id")) == cached["product_id"] for r in sql_rows
            )
            if not already_present:
                rows = await ProductRepository.get_by_ids([cached["product_id"]])
                sql_rows = rows + sql_rows
        return {"vector_hits": hits, "sql_rows": sql_rows, "order_rows": order_rows}

    async def _decide_route(self, state: ChatState) -> ChatState:
        """Decide template vs llm. Default to template; LLM only for true
        details / recommendation / FAQ-style asks."""
        intent = state.get("intent", "")
        q = state["customer_query"]

        # Greetings & escalations never need LLM
        if intent == "greeting":
            return {"route": "template"}

        # FAQs always go through LLM (vector hits need synthesis)
        if intent == "faq" or intent == "return_request":
            return {"route": "llm"}

        # Facet follow-up about an already-discussed product → template
        # (fast, deterministic, no LLM cost).
        if (
            _is_facet_followup(q)
            and not _wants_details(q)
            and not _mentions_product_noun(q)
        ):
            return {"route": "template"}

        # Anything mentioning a product type ("show me footwear", "any
        # sarees", "kurtis under 1000") → LLM. The grounding rule in the
        # system prompt lets Groq pick only the relevant products from the
        # vector context and ignore noise; that's more reliable than a
        # hard-coded category keyword list.
        if _mentions_product_noun(q):
            return {"route": "llm"}

        # Explicit "details about X" → LLM
        if _wants_details(q):
            return {"route": "llm"}

        # Default → template (covers any other product query).
        return {"route": "template"}

    async def _template_response(self, state: ChatState) -> ChatState:
        intent = state.get("intent", "")
        q = state["customer_query"]
        sql_rows = state.get("sql_rows") or []

        if intent == "greeting":
            return {
                "response": (
                    "Hi! I can help you with our sarees, kurtis, lehengas and more. "
                    "What are you looking for today?"
                ),
                "used_llm": False,
            }

        if intent == "order_tracking":
            return {
                "response": _format_orders(state.get("order_rows") or []),
                "used_llm": False,
            }

        if not sql_rows:
            return {
                "response": "I couldn't find a match for that. Could you give me a bit more detail?",
                "used_llm": False,
            }

        top = sql_rows[0]
        # Facet follow-ups: answer just the asked facet about top SQL row.
        # Skip when the query names a product type (it's a list query, not
        # a follow-up about one product).
        if _is_facet_followup(q) and not _mentions_product_noun(q):
            facet = _focused_facet_answer(q, top)
            if facet:
                return {"response": facet, "used_llm": False}

        # List view
        lines = ["Here are matches from our catalogue:"]
        for i, r in enumerate(sql_rows[:5], 1):
            price = r.get("base_price")
            mrp = r.get("suggested_mrp")
            colors = ", ".join(r.get("available_colors") or [])
            sizes = ", ".join(r.get("available_sizes") or [])
            line = f"{i}. {r.get('title') or '(no title)'}  —  ₹{price}"
            if mrp and mrp != price:
                line += f" (MRP ₹{mrp})"
            lines.append(line)
            details = []
            if r.get("category_name"):
                details.append(f"category: {r['category_name']}")
            if colors:
                details.append(f"colors: {colors}")
            if sizes:
                details.append(f"sizes: {sizes}")
            details.append(f"in stock: {r.get('total_stock', 0)}")
            lines.append("   " + "  |  ".join(details))
        return {"response": "\n".join(lines), "used_llm": False}

    async def _llm_response(self, state: ChatState) -> ChatState:
        sql_rows = (state.get("sql_rows") or [])[:3]
        vector_hits = (state.get("vector_hits") or [])[:3]
        history = (state.get("history") or [])[-2:]

        # Strip noisy fields so TOON output stays tight.
        sql_compact = [
            {
                "title": r.get("title"),
                "price": r.get("base_price"),
                "mrp": r.get("suggested_mrp"),
                "category": r.get("category_name"),
                "colors": r.get("available_colors") or [],
                "sizes": r.get("available_sizes") or [],
                "stock": r.get("total_stock", 0),
            }
            for r in sql_rows
        ]
        vec_compact = [
            {"title": (h.get("metadata") or {}).get("title"), "doc": h.get("document", "")[:300]}
            for h in vector_hits
        ]
        context_toon = toon_encode(
            {
                "products": sql_compact,
                "documents": vec_compact,
                "history": [{"role": h["role"], "content": h["content"]} for h in history],
            }
        )

        user_msg = (
            f"CONTEXT (TOON):\n{context_toon}\n\n"
            f"CUSTOMER QUERY: {state['customer_query']}\n"
            "Answer using only the context."
        )
        log.info(
            "llm_prompt",
            request_id=state.get("request_id"),
            model=get_settings().openai_model_chat,
            system_prompt=GRAPH_SYSTEM_PROMPT,
            user_prompt=user_msg,
        )
        response, _ = await self.llm.chat(
            purpose="graph_response",
            messages=[
                {"role": "system", "content": GRAPH_SYSTEM_PROMPT},
                {"role": "user", "content": user_msg},
            ],
            temperature=0.2,
            max_tokens=400,
        )
        log.info(
            "llm_response",
            request_id=state.get("request_id"),
            response=response,
        )
        # Regex validator — catches any made-up prices/orders that slipped through.
        v = self.validator.validate(
            response, sql_rows=sql_rows, vector_hits=vector_hits,
            customer_query=state["customer_query"],
        )
        if not v.valid:
            log.warning("graph_response_invalid", offending=v.offending)
        return {"response": response, "used_llm": True}

    async def _save_memory(self, state: ChatState) -> ChatState:
        conv = state["conversation_id"]
        await self.memory.append(conv, "user", state["customer_query"])
        await self.memory.append(conv, "assistant", state["response"])

        # Cache the top product for future facet follow-ups whenever the
        # turn was a product search and returned at least one row. The top
        # SQL row is our best guess for what the customer is focused on; a
        # later "what colors?" / "what sizes?" will answer about it.
        sql_rows = state.get("sql_rows") or []
        vector_hits = state.get("vector_hits") or []
        intent = state.get("intent", "")
        if sql_rows and intent == "product_search":
            top_id = str(sql_rows[0].get("id"))
            doc = next(
                (h.get("document", "") for h in vector_hits if str(h.get("id")) == top_id),
                "",
            )
            await self.memory.set_last_product(conv, top_id, doc)

        latency = int((time.perf_counter() - state["started"]) * 1000)
        return {"latency_ms": latency}

    # -- graph wiring ---------------------------------------------------------

    def _build_graph(self):
        g = StateGraph(ChatState)
        g.add_node("load_memory", self._load_memory)
        g.add_node("classify_intent", self._classify_intent)
        g.add_node("retrieve", self._retrieve)
        g.add_node("decide_route", self._decide_route)
        g.add_node("template_response", self._template_response)
        g.add_node("llm_response", self._llm_response)
        g.add_node("save_memory", self._save_memory)

        g.add_edge(START, "load_memory")
        g.add_edge("load_memory", "classify_intent")
        g.add_edge("classify_intent", "retrieve")
        g.add_edge("retrieve", "decide_route")
        g.add_conditional_edges(
            "decide_route",
            lambda s: s["route"],
            {"template": "template_response", "llm": "llm_response"},
        )
        g.add_edge("template_response", "save_memory")
        g.add_edge("llm_response", "save_memory")
        g.add_edge("save_memory", END)
        return g.compile()

    # -- public entry ---------------------------------------------------------

    async def handle(
        self,
        *,
        request_id: str,
        conversation_id: str | None,
        customer_query: str,
        customer_external_id: str | None,
        channel: str,
    ) -> dict[str, Any]:
        conversation_id = conversation_id or f"conv_{uuid.uuid4().hex[:12]}"
        initial: ChatState = {
            "conversation_id": conversation_id,
            "customer_query": customer_query,
            "customer_external_id": customer_external_id,
            "channel": channel,
            "request_id": request_id,
            "started": time.perf_counter(),
        }
        final = await self._graph.ainvoke(initial)
        log.info(
            "graph_done",
            request_id=request_id,
            conversation_id=conversation_id,
            customer_query=customer_query,
            intent=final.get("intent"),
            route=final.get("route"),
            used_llm=final.get("used_llm"),
            latency_ms=final.get("latency_ms"),
            response=final.get("response"),
        )
        return {
            "request_id": request_id,
            "conversation_id": conversation_id,
            "intent": final.get("intent"),
            "response": final["response"],
            "routing": None,
            "validation": "GRAPH",
            "escalated": False,
            "latency_ms": final.get("latency_ms", 0),
        }


def _phone_variants(raw: str) -> list[str]:
    """Return [raw, stripped-CC] so we match the DB whether or not the
    sender's number carried a +91 prefix."""
    raw = raw.strip().lstrip("+")
    out = [raw]
    # 12-digit numbers starting with the India country code → 10-digit form
    if len(raw) == 12 and raw.startswith("91"):
        out.append(raw[2:])
    # 11-digit numbers starting with leading 0 (e.g. 0xxxxxxxxxx) → strip 0
    elif len(raw) == 11 and raw.startswith("0"):
        out.append(raw[1:])
    return out


def _format_hits(hits: list[dict[str, Any]]) -> str:
    """Compact multi-line render of vector hits for log inspection.
    First 5 only, with rank, distance, title, and short id."""
    if not hits:
        return "(no hits)"
    out: list[str] = []
    for i, h in enumerate(hits[:5], 1):
        dist = h.get("distance")
        dist_s = f"{dist:.3f}" if isinstance(dist, (int, float)) else str(dist)
        meta = h.get("metadata") or {}
        title = meta.get("title") or (h.get("document") or "")[:40]
        cat = meta.get("category") or ""
        hid = str(h.get("id") or "")[:8]
        out.append(f"[{i}] dist={dist_s}  {title}  ({cat})  id={hid}…")
    if len(hits) > 5:
        out.append(f"… +{len(hits) - 5} more")
    return "\n".join(out)


def _format_orders(rows: list[dict[str, Any]]) -> str:
    if not rows:
        return (
            "I couldn't find any orders linked to this WhatsApp number. "
            "Please share your order number (e.g. SS-XX0000000000) and I'll "
            "look it up."
        )
    if len(rows) == 1:
        r = rows[0]
        lines = [
            f"Order {r.get('order_number')}:",
            f"  Status:   {r.get('order_status')}",
            f"  Payment:  {r.get('payment_status')}",
            f"  Total:    ₹{r.get('total_amount')}",
        ]
        if r.get("tracking_number"):
            lines.append(f"  Tracking: {r['tracking_number']}")
        if r.get("courier_name"):
            lines.append(f"  Courier:  {r['courier_name']}")
        if r.get("tracking_url"):
            lines.append(f"  Track:    {r['tracking_url']}")
        return "\n".join(lines)
    lines = [f"Found {len(rows)} orders on this number:"]
    for r in rows:
        placed = r.get("created_at")
        placed_str = placed.strftime("%Y-%m-%d") if placed else ""
        line = (
            f"  • {r.get('order_number')}  |  status: {r.get('order_status')}  "
            f"|  payment: {r.get('payment_status')}  |  ₹{r.get('total_amount')}"
        )
        if placed_str:
            line += f"  |  placed: {placed_str}"
        lines.append(line)
    return "\n".join(lines)


def _focused_facet_answer(query: str, row: dict[str, Any]) -> str | None:
    t = query.lower()
    title = row.get("title") or "this product"
    if "size" in t:
        sizes = ", ".join(row.get("available_sizes") or [])
        return f"{title} is available in sizes: {sizes or '—'}."
    if "color" in t or "colour" in t:
        colors = ", ".join(row.get("available_colors") or [])
        return f"{title} comes in: {colors or '—'}."
    if "stock" in t or "available" in t or "left" in t:
        stock = row.get("total_stock", 0)
        return f"{title} — {stock} in stock."
    if "price" in t or "cost" in t or "rate" in t or "rupee" in t:
        price = row.get("base_price")
        mrp = row.get("suggested_mrp")
        line = f"{title} is priced at ₹{price}"
        if mrp and mrp != price:
            line += f" (MRP ₹{mrp})"
        return line + "."
    if "fabric" in t or "material" in t:
        # fabric isn't in the SQL row; punt
        return None
    return None
