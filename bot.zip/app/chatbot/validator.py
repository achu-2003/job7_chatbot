"""Anti-hallucination validation layer.

The LLM is constrained by the system prompt, but we still verify its output
against the retrieved context. We check:

- every price mentioned (₹NNN, Rs NNN, INR NNN) exists in SQL rows
- every product/SKU name mentioned exists in retrieved data
- no order numbers / tracking numbers are quoted that weren't supplied
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Iterable


@dataclass
class ValidationResult:
    valid: bool
    reason: str = ""
    offending: list[str] | None = None


_PRICE_RX = re.compile(
    r"(?:₹|rs\.?|inr)\s*([0-9]+(?:[,\.][0-9]{2,3})*(?:\.[0-9]+)?)",
    re.IGNORECASE,
)
_ORDER_RX = re.compile(r"\b(?:SS-[A-Z]{2}\d{10,}|ORD[-_]?\d{3,})\b", re.IGNORECASE)
_TRACK_RX = re.compile(r"\b(?:AWB[-_]?[A-Z0-9-]{4,}|TRK[-_]?[A-Z0-9-]{4,})\b", re.IGNORECASE)


def _normalise_price(s: str) -> Decimal:
    return Decimal(s.replace(",", ""))


def _allowed_prices(sql_rows: Iterable[dict[str, Any]]) -> set[Decimal]:
    out: set[Decimal] = set()
    for r in sql_rows:
        for key in ("price", "base_price", "suggested_mrp", "unit_price",
                    "selling_price", "total_amount", "amount"):
            v = r.get(key)
            if v is None:
                continue
            try:
                out.add(Decimal(str(v)))
            except Exception:  # noqa: BLE001
                continue
    return out


def _allowed_names(sql_rows: Iterable[dict[str, Any]], vector_hits: Iterable[dict[str, Any]]) -> set[str]:
    names: set[str] = set()
    for r in sql_rows:
        for key in ("title", "name", "sku", "product_name"):
            if r.get(key):
                names.add(str(r[key]).lower())
    for h in vector_hits:
        md = h.get("metadata") or {}
        for key in ("title", "name", "sku"):
            if md.get(key):
                names.add(str(md[key]).lower())
    return names


def _allowed_order_numbers(sql_rows: Iterable[dict[str, Any]]) -> set[str]:
    return {str(r.get("order_number")).lower() for r in sql_rows if r.get("order_number")}


def _allowed_tracking_numbers(sql_rows: Iterable[dict[str, Any]]) -> set[str]:
    return {str(r.get("tracking_number")).lower() for r in sql_rows if r.get("tracking_number")}


class HallucinationValidator:
    def validate(
        self,
        response: str,
        *,
        sql_rows: list[dict[str, Any]],
        vector_hits: list[dict[str, Any]],
        customer_query: str | None = None,
    ) -> ValidationResult:
        offending: list[str] = []

        # Allowed prices: those returned by SQL plus any number the customer
        # already supplied (e.g. their stated budget). Echoing the customer's
        # own number back to them is not a hallucination.
        prices = _allowed_prices(sql_rows)
        if customer_query:
            for m in re.finditer(r"\b(\d+(?:[,\.]\d{2,3})*(?:\.\d+)?)\b", customer_query):
                try:
                    prices.add(_normalise_price(m.group(1)))
                except Exception:  # noqa: BLE001
                    continue
        for m in _PRICE_RX.finditer(response):
            try:
                amount = _normalise_price(m.group(1))
            except Exception:  # noqa: BLE001
                continue
            if amount not in prices:
                offending.append(f"unsupported_price:{amount}")

        order_allowed = _allowed_order_numbers(sql_rows)
        for m in _ORDER_RX.finditer(response):
            if m.group(0).lower() not in order_allowed:
                offending.append(f"unsupported_order:{m.group(0)}")

        track_allowed = _allowed_tracking_numbers(sql_rows)
        for m in _TRACK_RX.finditer(response):
            if m.group(0).lower() not in track_allowed:
                offending.append(f"unsupported_tracking:{m.group(0)}")

        # Product name check: if a quoted "Foo Bar Saree"-style phrase doesn't
        # appear in retrieved data, flag it. Heuristic, low recall by design.
        allowed_names = _allowed_names(sql_rows, vector_hits)
        for quoted in re.findall(r"\"([^\"]{3,80})\"", response):
            normalised = quoted.lower().strip(" \t\n,.!?;:'\"-")
            if not normalised:
                continue
            if normalised in allowed_names:
                continue
            if any(normalised in n or n in normalised for n in allowed_names):
                continue
            offending.append(f"unsupported_name:{quoted}")

        if offending:
            return ValidationResult(
                valid=False,
                reason="grounding_failed",
                offending=offending,
            )
        return ValidationResult(valid=True)
