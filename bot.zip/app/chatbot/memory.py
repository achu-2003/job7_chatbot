"""Multi-turn conversational memory backed by Redis.

A conversation is identified by ``conversation_id``. The list contains the
last N message turns serialised as JSON. TTL bounds memory cost.
"""
from __future__ import annotations

import json
from typing import Any

import redis.asyncio as redis

from app.config import get_settings
from app.core.logging import get_logger

log = get_logger("memory")

_MAX_TURNS = 12


class ConversationMemory:
    def __init__(self) -> None:
        self._redis: redis.Redis | None = None
        self._ttl = get_settings().redis_memory_ttl_seconds

    async def connect(self) -> None:
        self._redis = redis.from_url(
            get_settings().redis_url, decode_responses=True
        )
        await self._redis.ping()
        log.info("memory_ready")

    async def close(self) -> None:
        if self._redis is not None:
            await self._redis.aclose()
            self._redis = None

    def _key(self, conv_id: str) -> str:
        return f"conv:{conv_id}:history"

    def _last_product_key(self, conv_id: str) -> str:
        return f"conv:{conv_id}:last_product"

    async def append(self, conv_id: str, role: str, content: str) -> None:
        assert self._redis is not None
        payload = json.dumps({"role": role, "content": content})
        async with self._redis.pipeline(transaction=True) as pipe:
            pipe.rpush(self._key(conv_id), payload)
            pipe.ltrim(self._key(conv_id), -_MAX_TURNS, -1)
            pipe.expire(self._key(conv_id), self._ttl)
            await pipe.execute()

    async def history(self, conv_id: str) -> list[dict[str, Any]]:
        assert self._redis is not None
        raw = await self._redis.lrange(self._key(conv_id), 0, -1)
        out: list[dict[str, Any]] = []
        for item in raw:
            try:
                out.append(json.loads(item))
            except json.JSONDecodeError:
                continue
        return out

    async def clear(self, conv_id: str) -> None:
        assert self._redis is not None
        await self._redis.delete(self._key(conv_id))

    async def set_last_product(
        self, conv_id: str, product_id: str, doc: str
    ) -> None:
        """Cache the last single-product detail shown to the customer.

        Used by the no-LLM follow-up path so terse turns like "what sizes?"
        can resolve back to the product just discussed.
        """
        assert self._redis is not None
        payload = json.dumps({"product_id": product_id, "doc": doc})
        await self._redis.setex(
            self._last_product_key(conv_id), self._ttl, payload
        )

    async def get_last_product(self, conv_id: str) -> dict[str, str] | None:
        assert self._redis is not None
        raw = await self._redis.get(self._last_product_key(conv_id))
        if not raw:
            return None
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return None
