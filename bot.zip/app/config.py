from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # ---- app ----
    app_env: Literal["development", "staging", "production"] = "production"
    app_name: str = "ecom-crm-chatbot"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    log_level: str = "INFO"
    json_logs: bool = True

    # ---- postgres ----
    database_url: str
    postgres_host: str = "postgres"
    postgres_port: int = 5432
    postgres_db: str = "ecom_crm"
    postgres_user: str = "ecom"
    postgres_password: str = ""

    # ---- redis ----
    redis_url: str = "redis://redis:6379/0"
    redis_queue_key: str = "embedding_jobs"
    redis_memory_ttl_seconds: int = 3600

    # ---- chroma ----
    vector_mode: Literal["http", "embedded"] = "http"
    chroma_host: str = "chroma"
    chroma_port: int = 8000
    chroma_persist_dir: str = "./data/chroma"
    chroma_collection_products: str = "products"
    chroma_collection_faq: str = "faqs"
    chroma_collection_policies: str = "policies"

    # ---- native dev ----
    run_worker_in_api: bool = False  # bundle worker as asyncio task in api

    # ---- LLM (Groq via OpenAI-compatible API; see LLM_BASE_URL) ----
    # Legacy flag kept for downstream tooling. The LangGraph pipeline calls
    # the LLM only on "details / recommend / FAQ / return" turns regardless.
    llm_enabled: bool = True
    openai_api_key: str = Field(default="")
    openai_model_chat: str = "gpt-4o-mini"
    openai_model_router: str = "gpt-4o-mini"
    openai_model_embed: str = "text-embedding-3-small"
    openai_embed_dimensions: int = 512
    openai_timeout_seconds: int = 20
    openai_max_retries: int = 2

    # ---- local LLM (llama.cpp server, OpenAI-compatible) ----
    # When llm_base_url is set, AsyncOpenAI points at it instead of OpenAI.
    llm_base_url: str = Field(default="")
    # fastembed model name; 384-dim, runs on CPU via ONNX.
    local_embed_model: str = "BAAI/bge-small-en-v1.5"
    local_embed_dimensions: int = 384

    # ---- retrieval ----
    vector_top_k: int = 5
    sql_max_rows: int = 10
    intent_confidence_threshold: float = 0.55
    escalation_keywords: str = "refund,fraud,legal,complaint,manager"

    # ---- observability ----
    prometheus_enabled: bool = True

    # ---- whatsapp / meta cloud api ----
    meta_access_token: str = Field(default="")
    meta_phone_number_id: str = Field(default="")
    whatsapp_verify_token: str = Field(default="")
    whatsapp_graph_version: str = "v22.0"

    @property
    def escalation_keyword_list(self) -> list[str]:
        return [k.strip().lower() for k in self.escalation_keywords.split(",") if k.strip()]


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]
