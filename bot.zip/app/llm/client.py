"""Thin async wrapper over the OpenAI client with metrics + retries."""
from __future__ import annotations

import json
import time
from typing import Any

from openai import AsyncOpenAI
from openai.types.chat import ChatCompletionMessageParam
from tenacity import (
    AsyncRetrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.config import get_settings
from app.core.logging import get_logger
from app.core.metrics import OPENAI_LATENCY, OPENAI_TOKENS

log = get_logger("openai")


class LLMClient:
    def __init__(self, client: AsyncOpenAI | None = None) -> None:
        s = get_settings()
        self._settings = s
        if client is not None:
            self._client = client
        else:
            kwargs: dict[str, Any] = {
                "timeout": s.openai_timeout_seconds,
                "max_retries": 0,
            }
            # Local llama.cpp server exposes an OpenAI-compatible /v1
            # endpoint, so we just redirect the OpenAI SDK at it.
            if s.llm_base_url:
                kwargs["base_url"] = s.llm_base_url
                kwargs["api_key"] = s.openai_api_key or "sk-local-noop"
            else:
                kwargs["api_key"] = s.openai_api_key
            self._client = AsyncOpenAI(**kwargs)

    async def chat(
        self,
        *,
        purpose: str,
        messages: list[ChatCompletionMessageParam],
        model: str | None = None,
        temperature: float = 0.2,
        response_format: dict[str, Any] | None = None,
        max_tokens: int | None = 800,
    ) -> tuple[str, dict[str, int]]:
        s = self._settings
        model = model or s.openai_model_chat
        start = time.perf_counter()

        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(s.openai_max_retries + 1),
            # max bumped to 20s so a Groq 429 (TPM resets each minute) gets
            # backed off long enough to clear on the next attempt.
            wait=wait_exponential(min=0.5, max=20),
            retry=retry_if_exception_type(Exception),
            reraise=True,
        ):
            with attempt:
                kwargs: dict[str, Any] = {
                    "model": model,
                    "messages": messages,
                    "temperature": temperature,
                    "max_tokens": max_tokens,
                }
                if response_format is not None:
                    kwargs["response_format"] = response_format
                resp = await self._client.chat.completions.create(**kwargs)

        text = resp.choices[0].message.content or ""
        usage = {
            "prompt_tokens": getattr(resp.usage, "prompt_tokens", 0) or 0,
            "completion_tokens": getattr(resp.usage, "completion_tokens", 0) or 0,
            "total_tokens": getattr(resp.usage, "total_tokens", 0) or 0,
        }
        OPENAI_TOKENS.labels(model=model, kind="prompt").inc(usage["prompt_tokens"])
        OPENAI_TOKENS.labels(model=model, kind="completion").inc(usage["completion_tokens"])
        OPENAI_LATENCY.labels(model=model, purpose=purpose).observe(time.perf_counter() - start)
        return text, usage

    async def json_chat(
        self,
        *,
        purpose: str,
        messages: list[ChatCompletionMessageParam],
        model: str | None = None,
        temperature: float = 0.0,
    ) -> tuple[dict[str, Any], dict[str, int]]:
        text, usage = await self.chat(
            purpose=purpose,
            messages=messages,
            model=model,
            temperature=temperature,
            response_format={"type": "json_object"},
        )
        try:
            return json.loads(text), usage
        except json.JSONDecodeError as exc:
            log.warning("json_parse_failed", purpose=purpose, raw=text[:300])
            raise exc
