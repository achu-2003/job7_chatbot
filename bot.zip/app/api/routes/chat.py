"""Customer-facing chat endpoint.

Single POST endpoint shared by WhatsApp, web, and mobile clients. The
``channel`` field on the request distinguishes them. All requests run
through the LangGraph chat runner (vector-first retrieval, template
responses for common asks, Groq for "details/recommend/FAQ" queries).
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from fastapi.responses import ORJSONResponse

from app.api.deps import get_graph
from app.chatbot.graph import ChatGraphRunner
from app.core.logging import request_id_var
from app.schemas.chat import ChatRequest, ChatResponse

router = APIRouter(default_response_class=ORJSONResponse)


@router.post("", response_model=ChatResponse, summary="Send a customer message")
async def chat(
    body: ChatRequest,
    graph: ChatGraphRunner = Depends(get_graph),
) -> ChatResponse:
    request_id = request_id_var.get() or "REQ_unknown"
    result = await graph.handle(
        request_id=request_id,
        conversation_id=body.conversation_id,
        customer_query=body.message,
        customer_external_id=body.customer_external_id,
        channel=body.channel,
    )
    return ChatResponse(**result)
