"""WhatsApp Cloud API webhook.

Meta sends two flavors of traffic here:

* GET  /api/whatsapp/webhook  — verification handshake (echo hub.challenge).
* POST /api/whatsapp/webhook  — incoming customer messages.

The POST handler dispatches text messages through the in-process LangGraph
chat runner (no HTTP loopback) and then sends the reply back via the Meta
Graph API using async ``httpx``.
"""
from __future__ import annotations

from typing import Any

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import ORJSONResponse, PlainTextResponse

from app.api.deps import get_graph
from app.chatbot.graph import ChatGraphRunner
from app.config import get_settings
from app.core.logging import get_logger, request_id_var

router = APIRouter()
log = get_logger("whatsapp")


@router.get("/webhook", response_class=PlainTextResponse)
async def verify_webhook(
    hub_mode: str | None = Query(default=None, alias="hub.mode"),
    hub_verify_token: str | None = Query(default=None, alias="hub.verify_token"),
    hub_challenge: str | None = Query(default=None, alias="hub.challenge"),
) -> PlainTextResponse:
    settings = get_settings()
    log.info("whatsapp_verify_request", mode=hub_mode)

    if hub_verify_token == settings.whatsapp_verify_token and hub_challenge:
        log.info("whatsapp_verify_ok")
        return PlainTextResponse(hub_challenge, status_code=200)

    log.warning("whatsapp_verify_failed")
    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/webhook", response_class=ORJSONResponse)
async def receive_webhook(
    request: Request,
) -> ORJSONResponse:
    settings = get_settings()
    request_id = request_id_var.get() or "REQ_unknown"

    try:
        payload: dict[str, Any] = await request.json()
    except Exception:  # noqa: BLE001
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    log.info("whatsapp_webhook_received", payload=payload)

    message = _extract_text_message(payload)
    if message is None:
        # status updates, delivery receipts, non-text — ack and ignore
        return ORJSONResponse({"status": "ignored"}, status_code=200)

    customer_number: str = _normalize_phone(message["from"])
    incoming_text: str = message["text"]

    # ------------------------------------------------------------------
    # Conversation memory is keyed strictly by the sender's normalized
    # phone number. Two different phones → two different Redis keys
    # (conv:wa_<digits>:history, conv:wa_<digits>:last_product) → no
    # cross-contamination between customers. Same phone across reconnects
    # → same key → conversation continues where it left off.
    # ------------------------------------------------------------------
    conversation_id = f"wa_{customer_number}"

    log.info(
        "whatsapp_message_in",
        sender=customer_number,
        conversation_id=conversation_id,
        text=incoming_text,
    )

    runner: ChatGraphRunner = get_graph(request)
    result = await runner.handle(
        request_id=request_id,
        conversation_id=conversation_id,
        customer_query=incoming_text,
        customer_external_id=customer_number,
        channel="whatsapp",
    )
    bot_reply: str = (
        result.get("response")
        or "Sorry, I couldn't process your request."
    )
    log.info("whatsapp_ai_reply", reply=bot_reply)

    # ------------------------------------------------------------------
    # Send reply back to Meta — always to the original sender
    # ------------------------------------------------------------------
    to_number = customer_number
    graph_url = (
        f"https://graph.facebook.com/{settings.whatsapp_graph_version}/"
        f"{settings.meta_phone_number_id}/messages"
    )
    wa_payload = {
        "messaging_product": "whatsapp",
        "recipient_type": "individual",
        "to": to_number,
        "type": "text",
        "text": {"body": bot_reply},
    }
    headers = {
        "Authorization": f"Bearer {settings.meta_access_token}",
        "Content-Type": "application/json",
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        try:
            resp = await client.post(graph_url, json=wa_payload, headers=headers)
        except httpx.HTTPError as exc:
            log.exception("whatsapp_send_error", error=str(exc))
            raise HTTPException(status_code=502, detail="WhatsApp send failed")

    log.info(
        "whatsapp_send_response",
        status=resp.status_code,
        body=resp.text[:500],
    )
    if resp.status_code not in (200, 201):
        raise HTTPException(status_code=502, detail="WhatsApp API rejected message")

    return ORJSONResponse(
        {
            "status": "success",
            "customer": to_number,
            "message": incoming_text,
            "reply": bot_reply,
        },
        status_code=200,
    )


def _normalize_phone(raw: str) -> str:
    """Canonicalise a phone identifier for memory keys + outbound delivery.

    Strips whitespace, the leading ``+``, and any non-digit characters
    (Meta occasionally injects formatting). Returns a digits-only string.
    Same input → same output → same Redis key, so two messages from the
    same WhatsApp sender always share a memory session even if Meta
    changes its representation between requests.
    """
    return "".join(ch for ch in (raw or "").strip().lstrip("+") if ch.isdigit())


def _extract_text_message(payload: dict[str, Any]) -> dict[str, str] | None:
    try:
        value = payload["entry"][0]["changes"][0]["value"]
    except (KeyError, IndexError, TypeError):
        return None

    messages = value.get("messages")
    if not messages:
        return None

    msg = messages[0]
    if msg.get("type") != "text":
        return None

    body = (msg.get("text") or {}).get("body", "").strip()
    sender = msg.get("from")
    if not body or not sender:
        return None

    return {"from": str(sender), "text": body}
