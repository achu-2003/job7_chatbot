"""Admin endpoints.

POST /reindex
    Builds embedding jobs for every ACTIVE product in public.products plus
    every FAQ and policy from content/*.json, and enqueues them. The
    embedding worker consumes the queue and UPSERTs into the vector store.

GET /reindex/status
    Returns the current queue depth.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends
from fastapi.responses import ORJSONResponse

from app.api.deps import get_queue
from app.config import get_settings
from app.db.repositories import ProductRepository
from app.workers.queue import EmbeddingQueue

router = APIRouter(default_response_class=ORJSONResponse)

CONTENT_DIR = Path(__file__).resolve().parents[3] / "content"


def _product_document(row: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    colors = ", ".join(row.get("available_colors") or [])
    sizes = ", ".join(row.get("available_sizes") or [])
    keywords = ", ".join(row.get("search_keywords") or [])
    parts = [
        f"TITLE: {row['title']}",
        f"CATEGORY: {row.get('category_name') or 'unknown'}",
        f"GENDER: {row.get('gender') or 'unisex'}",
        f"FABRIC: {row.get('fabric') or '-'}",
        f"COLORS: {colors or '-'}",
        f"SIZES: {sizes or '-'}",
        f"KEYWORDS: {keywords or '-'}",
        f"DESCRIPTION: {row.get('description') or ''}",
    ]
    document = "\n".join(parts)
    metadata = {
        "product_id": row["id"],
        "title": row["title"],
        "category": row.get("category_name"),
        "gender": row.get("gender"),
    }
    metadata = {k: v for k, v in metadata.items() if v is not None}
    return document, metadata


def _faq_document(item: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    doc = f"Q: {item['question']}\nA: {item['answer']}"
    return doc, {"tags": ", ".join(item.get("tags", []))}


def _policy_document(item: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    doc = f"{item['title']}\n{item['body']}"
    return doc, {"category": item.get("category", "")}


def _load_json(name: str) -> list[dict[str, Any]]:
    path = CONTENT_DIR / name
    if not path.exists():
        return []
    return json.loads(path.read_text(encoding="utf-8"))


@router.post("/reindex", summary="Re-embed products, FAQs and policies")
async def reindex(queue: EmbeddingQueue = Depends(get_queue)) -> dict[str, int]:
    s = get_settings()
    counts = {"products": 0, "faqs": 0, "policies": 0}

    # ---- products from live DB
    rows = await ProductRepository.iter_active_for_embedding()
    for row in rows:
        document, metadata = _product_document(row)
        await queue.enqueue(
            {
                "action": "upsert",
                "collection": s.chroma_collection_products,
                "id": row["id"],
                "document": document,
                "metadata": metadata,
            }
        )
    counts["products"] = len(rows)

    # ---- FAQs from JSON
    for item in _load_json("faqs.json"):
        document, metadata = _faq_document(item)
        await queue.enqueue(
            {
                "action": "upsert",
                "collection": s.chroma_collection_faq,
                "id": item["id"],
                "document": document,
                "metadata": metadata,
            }
        )
        counts["faqs"] += 1

    # ---- Policies from JSON
    for item in _load_json("policies.json"):
        document, metadata = _policy_document(item)
        await queue.enqueue(
            {
                "action": "upsert",
                "collection": s.chroma_collection_policies,
                "id": item["id"],
                "document": document,
                "metadata": metadata,
            }
        )
        counts["policies"] += 1

    return counts


@router.get("/reindex/status")
async def reindex_status(queue: EmbeddingQueue = Depends(get_queue)) -> dict[str, int]:
    depth = await queue.depth()
    return {"queue_depth": depth}
