"""Shared FastAPI dependencies (state-bound singletons created at startup)."""
from __future__ import annotations

from fastapi import Request

from app.chatbot.graph import ChatGraphRunner
from app.chatbot.memory import ConversationMemory
from app.vector.store import VectorStore
from app.workers.queue import EmbeddingQueue


def get_vector(request: Request) -> VectorStore:
    return request.app.state.vector


def get_memory(request: Request) -> ConversationMemory:
    return request.app.state.memory


def get_queue(request: Request) -> EmbeddingQueue:
    return request.app.state.queue


def get_graph(request: Request) -> ChatGraphRunner:
    return request.app.state.graph_runner
