"""Generic embedding worker.

Queue contract — every job is one of:

    {"action": "upsert", "collection": "<name>",
     "id": "<id>", "document": "<text>", "metadata": {...}}

    {"action": "delete", "collection": "<name>", "ids": ["<id>", ...]}

The reindex endpoint is the only producer (we don't write to the prod DB, so
there is no LISTEN/NOTIFY trigger). Upserts are idempotent — re-running
reindex any time is safe.
"""
from __future__ import annotations

import asyncio
import signal
from typing import Any

from app.core.logging import configure_logging, get_logger
from app.core.metrics import EMBED_QUEUE_DEPTH, ERROR_COUNTER
from app.db.session import close_engine, init_engine
from app.vector.store import VectorStore
from app.workers.queue import EmbeddingQueue

configure_logging()
log = get_logger("embedding_worker")


class Worker:
    """Embedding sync worker. Can run standalone or bundled into the API."""

    def __init__(
        self,
        *,
        vector: VectorStore | None = None,
        queue: EmbeddingQueue | None = None,
        owns_resources: bool = True,
    ) -> None:
        self._vector = vector or VectorStore()
        self._queue = queue or EmbeddingQueue()
        self._owns_resources = owns_resources
        self._stop = asyncio.Event()

    async def run(self, *, install_signal_handlers: bool = True) -> None:
        if self._owns_resources:
            await init_engine()
            await self._queue.connect()
            await self._vector.connect()

        if install_signal_handlers:
            loop = asyncio.get_running_loop()
            for sig in (signal.SIGTERM, signal.SIGINT):
                try:
                    loop.add_signal_handler(sig, self._stop.set)
                except NotImplementedError:
                    pass

        try:
            await self._consume()
        finally:
            if self._owns_resources:
                await self._vector.close()
                await self._queue.close()
                await close_engine()

    async def start_in_background(self) -> asyncio.Task:
        return asyncio.create_task(self.run(install_signal_handlers=False),
                                   name="embedding_worker")

    def stop(self) -> None:
        self._stop.set()

    # ------------------------------------------------------------------

    async def _consume(self) -> None:
        while not self._stop.is_set():
            try:
                event = await self._queue.dequeue(timeout=2)
                if event is None:
                    continue
                depth = await self._queue.depth()
                EMBED_QUEUE_DEPTH.observe(depth)
                await self._process(event)
            except Exception as exc:  # noqa: BLE001
                ERROR_COUNTER.labels(layer="embedding_worker").inc()
                log.exception("worker_process_error", error=str(exc))

    async def _process(self, event: dict[str, Any]) -> None:
        action = event.get("action")
        collection = event.get("collection")
        if not action or not collection:
            log.warning("invalid_event", event=event)
            return

        if action == "upsert":
            ident = event.get("id")
            doc = event.get("document")
            if not ident or not doc:
                log.warning("invalid_upsert", event=event)
                return
            await self._vector.upsert(
                collection,
                ids=[ident],
                documents=[doc],
                metadatas=[event.get("metadata") or {}],
            )
        elif action == "delete":
            ids = event.get("ids") or []
            if ids:
                await self._vector.delete(collection, ids)
        else:
            log.warning("unknown_action", action=action)


def main() -> None:
    worker = Worker()
    try:
        asyncio.run(worker.run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
